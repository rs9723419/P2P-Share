import React, { useState, useRef, useEffect } from "react";
import { 
  Upload, 
  Folder, 
  FileUp, 
  Copy, 
  Check, 
  Loader2, 
  X, 
  Lock, 
  Clock, 
  QrCode, 
  Share2, 
  Trash2, 
  File, 
  FileSpreadsheet,
  AlertCircle,
  TrendingUp,
  Settings,
  HardDrive
} from "lucide-react";
import { doc, setDoc } from "firebase/firestore";
import { db } from "../lib/firebase";
import QRCode from "qrcode";
import JSZip from "jszip";
import AnalyticsPanel from "./AnalyticsPanel";
import { motion, AnimatePresence } from "motion/react";

interface LocalShare {
  id: string;
  name: string;
  size: number;
  uploadedAt: string;
  expiration: string;
  passwordProtected: boolean;
}

export default function SendSection() {
  // Selected files pile
  const [selectedFiles, setSelectedFiles] = useState<any[]>([]);
  const [isFolderMode, setIsFolderMode] = useState(false);
  const [folderName, setFolderName] = useState("");

  // Options states
  const [password, setPassword] = useState("");
  const [usePassword, setUsePassword] = useState(false);
  const [expirationOption, setExpirationOption] = useState("168"); // Default 7 days (in hours)

  // Uploading state tracking
  const [uploadState, setUploadState] = useState<"idle" | "zipping" | "uploading" | "completed" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const [uploadPercent, setUploadPercent] = useState(0);
  const [zipPercent, setZipPercent] = useState(0);
  const [uploadSpeed, setUploadSpeed] = useState("");
  const [bytesUploaded, setBytesUploaded] = useState(0);
  const [totalBytesToUpload, setTotalBytesToUpload] = useState(0);
  const [estimatedRemainingSeconds, setEstimatedRemainingSeconds] = useState<number | null>(null);

  // Sharing result
  const [shareResult, setShareResult] = useState<{ id: string; url: string } | null>(null);
  const [isLinkCopied, setIsLinkCopied] = useState(false);
  
  // Local upload history to let senders view real-time log statistics of their active files
  const [uploadedHistory, setUploadedHistory] = useState<LocalShare[]>([]);
  const [activeAnalyticsId, setActiveAnalyticsId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  const qrCanvasRef = useRef<HTMLCanvasElement>(null);
  const uploadHistoryRef = useRef<{ timestamp: number; bytes: number }[]>([]);

  // Load local shares on boot
  useEffect(() => {
    try {
      const saved = localStorage.getItem("local_cloud_shares");
      if (saved) {
        setUploadedHistory(JSON.parse(saved));
      }
    } catch (e) {
      console.warn("Storage history reading issues:", e);
    }
  }, []);

  // Save local history whenever it changes
  const saveToLocalHistory = (list: LocalShare[]) => {
    try {
      localStorage.setItem("local_cloud_shares", JSON.stringify(list));
      setUploadedHistory(list);
    } catch (e) {}
  };

  // Generate QR Code dynamically when shareResults are returned
  useEffect(() => {
    if (qrCanvasRef.current && shareResult) {
      QRCode.toCanvas(
        qrCanvasRef.current,
        shareResult.url,
        {
          width: 140,
          margin: 1.5,
          color: {
            dark: "#0f172a", // Deep Slate-900
            light: "#ffffff"
          }
        },
        (error) => {
          if (error) console.error("[QR Code Canvas Generator Failed]:", error);
        }
      );
    }
  }, [shareResult]);

  // Handle drag over container
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      processFiles(e.target.files);
    }
  };

  const processFiles = (files: FileList) => {
    const list: any[] = [];
    let detectedFolder = "";

    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      const relPath = f.webkitRelativePath || f.name;

      if (f.webkitRelativePath) {
        const parts = f.webkitRelativePath.split("/");
        if (parts.length > 0 && !detectedFolder) {
          detectedFolder = parts[0];
        }
      }

      list.push({
        fileObject: f,
        name: f.name,
        size: f.size,
        type: f.type || "application/octet-stream",
        relativePath: relPath
      });
    }

    if (detectedFolder) {
      setIsFolderMode(true);
      setFolderName(detectedFolder);
    }

    setSelectedFiles(prev => [...prev, ...list]);
  };

  const removeFile = (idx: number) => {
    setSelectedFiles(prev => {
      const filter = prev.filter((_, i) => i !== idx);
      if (filter.length === 0) {
        setIsFolderMode(false);
        setFolderName("");
      }
      return filter;
    });
  };

  // SHA-256 helper
  const sha256 = async (str: string): Promise<string> => {
    const msgBuffer = new TextEncoder().encode(str);
    const hashBuffer = await crypto.subtle.digest("SHA-256", msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
  };

  const generateFileId = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let res = "";
    for (let i = 0; i < 8; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return res;
  };

  const handleTriggerUpload = async () => {
    if (selectedFiles.length === 0) return;

    setUploadState("zipping");
    setZipPercent(0);
    setErrorMessage("");
    uploadHistoryRef.current = [];

    try {
      let fileToUpload: File;

      // Pack files if there are multiple or if we are in folder mode
      if (selectedFiles.length === 1 && !isFolderMode) {
        fileToUpload = selectedFiles[0].fileObject;
      } else {
        const zip = new JSZip();
        selectedFiles.forEach((f) => {
          zip.file(f.relativePath, f.fileObject);
        });
        
        // Fast raw-packing of directory. Using "STORE" avoids expensive CPU Deflate compress cycles,
        // while streamFiles: true minimizes system thread blocking on browser container.
        const zipBlob = await zip.generateAsync({
          type: "blob",
          compression: "STORE",
          streamFiles: true
        }, (update) => {
          setZipPercent(Math.round(update.percent));
        });
        
        const zipName = `${folderName || "archive"}_files.zip`;
        fileToUpload = new File([zipBlob], zipName, { type: "application/zip" });
      }

      setUploadState("uploading");
      setUploadPercent(0);
      setBytesUploaded(0);
      setTotalBytesToUpload(fileToUpload.size);
      
      const fileId = generateFileId();
      const startTime = Date.now();
      
      const xhr = new XMLHttpRequest();
      xhr.open("POST", `/api/upload/${fileId}/${encodeURIComponent(fileToUpload.name)}`, true);
      xhr.setRequestHeader("Content-Type", fileToUpload.type || "application/octet-stream");
      
      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const now = Date.now();
          const loaded = event.loaded;
          const total = event.total;
          const percentage = Math.round((loaded / total) * 100);
          
          setUploadPercent(percentage);
          setBytesUploaded(loaded);

          // Append current progress record
          uploadHistoryRef.current.push({ timestamp: now, bytes: loaded });
          
          // Prune rolling telemetry older than 3 seconds
          uploadHistoryRef.current = uploadHistoryRef.current.filter(
            item => now - item.timestamp <= 3000
          );

          // Calculate current rolling upload speed
          let speed = 0;
          if (uploadHistoryRef.current.length > 1) {
            const first = uploadHistoryRef.current[0];
            const last = uploadHistoryRef.current[uploadHistoryRef.current.length - 1];
            const timeDiff = (last.timestamp - first.timestamp) / 1000;
            const bytesDiff = last.bytes - first.bytes;
            if (timeDiff > 0.1) {
              speed = bytesDiff / timeDiff;
            }
          }

          if (speed <= 0) {
            // fallback overall average
            const elapsedSecs = (now - startTime) / 1000;
            if (elapsedSecs > 0) {
              speed = loaded / elapsedSecs;
            }
          }

          if (speed > 0) {
            if (speed > 1024 * 1024) {
              setUploadSpeed(`${(speed / (1024 * 1024)).toFixed(1)} MB/s`);
            } else {
              setUploadSpeed(`${(speed / 1024).toFixed(0)} KB/s`);
            }

            // ETA computation
            const bytesRemaining = total - loaded;
            const eta = Math.round(bytesRemaining / speed);
            setEstimatedRemainingSeconds(eta);
          }
        }
      };

      xhr.onerror = (error) => {
        console.error("Local Server Upload Connection Error:", error);
        setErrorMessage("Failed to upload file to backend server cache. Please check container health.");
        setUploadState("error");
      };

      xhr.onload = async () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const response = JSON.parse(xhr.responseText);
            const downloadUrl = response.downloadUrl;

            // Calculate Expiration
            let expTimestamp: string = "never";
            if (expirationOption && expirationOption !== "never") {
              const h = parseInt(expirationOption);
              expTimestamp = new Date(Date.now() + h * 60 * 60 * 1000).toISOString();
            }

            // Calculate Password Hash
            let passHash = "";
            if (usePassword && password) {
              passHash = await sha256(password);
            }

            // Save Document metadata in Firestore
            const cloudDoc = {
              id: fileId,
              fileName: fileToUpload.name,
              mimeType: fileToUpload.type || "application/octet-stream",
              size: fileToUpload.size,
              uploadedAt: new Date().toISOString(),
              storagePath: `shared_files/${fileId}/${fileToUpload.name}`,
              downloadUrl: downloadUrl,
              passwordHash: passHash || null,
              expiration: expTimestamp,
              downloadCount: 0,
              analytics: []
            };

            await setDoc(doc(db, "shared_files", fileId), cloudDoc);

            // Record to persistent History
            const shareUrl = `${window.location.origin}/download/${fileId}`;
            const newShare: LocalShare = {
              id: fileId,
              name: fileToUpload.name,
              size: fileToUpload.size,
              uploadedAt: cloudDoc.uploadedAt,
              expiration: expTimestamp,
              passwordProtected: !!passHash
            };

            saveToLocalHistory([newShare, ...uploadedHistory]);
            setShareResult({ id: fileId, url: shareUrl });
            setUploadState("completed");

            // Reset selection files pool
            setSelectedFiles([]);
            setIsFolderMode(false);
            setFolderName("");
          } catch (err: any) {
            console.error("Firestore Upload Registry Failed:", err);
            setErrorMessage("Direct cloud upload completed, but metadata database registration failed: " + err.message);
            setUploadState("error");
          }
        } else {
          console.error("Local Server Upload Rejected. Status code:", xhr.status);
          setErrorMessage(`File stream upload rejected by host server. Code: ${xhr.status}`);
          setUploadState("error");
        }
      };

      // Send raw file stream
      xhr.send(fileToUpload);

    } catch (e: any) {
      console.error(e);
      setErrorMessage("System pack error occurred: " + e.message);
      setUploadState("error");
    }
  };

  const handleCopyLink = () => {
    if (shareResult) {
      navigator.clipboard.writeText(shareResult.url);
      setIsLinkCopied(true);
      setTimeout(() => setIsLinkCopied(false), 2000);
    }
  };

  const handleDeleteHistoryItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const clean = uploadedHistory.filter((item) => item.id !== id);
    saveToLocalHistory(clean);
    if (activeAnalyticsId === id) {
      setActiveAnalyticsId(null);
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  return (
    <div className="space-y-8">
      {/* Upload Panel Card */}
      <div className="bg-white border border-slate-100 rounded-3xl p-6 sm:p-8 shadow-md">
        
        <AnimatePresence mode="wait">
          {uploadState === "idle" && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              {/* Symmetrical Dropzone */}
              <div
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                className="border-2 border-dashed border-slate-200 hover:border-blue-400 bg-slate-50/20 hover:bg-slate-50/70 py-10 px-4 rounded-2xl text-center space-y-4 transition duration-150 cursor-pointer group"
                onClick={() => fileInputRef.current?.click()}
              >
                <div className="p-3 bg-blue-50 text-blue-600 rounded-xl max-w-max mx-auto border border-blue-100 group-hover:scale-105 transition transform">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-display font-bold text-slate-800 text-sm tracking-tight">
                    Drag and drop your file or directory here
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1 font-sans">
                    Supports documents, compressed binaries, videos, audio up to unlimited sizes
                  </p>
                </div>
                <div className="flex justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      fileInputRef.current?.click();
                    }}
                    className="p-1.5 px-3 rounded-lg border border-slate-200 bg-white shadow-3xs text-[11px] font-bold text-slate-600 hover:bg-slate-50 flex items-center gap-1 cursor-pointer"
                  >
                    <FileUp className="w-3.5 h-3.5" />
                    Select file
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      folderInputRef.current?.click();
                    }}
                    className="p-1.5 px-3 rounded-lg border border-slate-200 bg-white shadow-3xs text-[11px] font-bold text-slate-600 hover:bg-slate-50 flex items-center gap-1 cursor-pointer"
                  >
                    <Folder className="w-3.5 h-3.5" />
                    Select folder
                  </button>
                </div>

                <input
                  type="file"
                  multiple
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                />
                <input
                  type="file"
                  ref={folderInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                  webkitdirectory=""
                  directory=""
                />
              </div>

              {/* Multi-Files Selector Stack */}
              {selectedFiles.length > 0 && (
                <div className="space-y-3">
                  <div className="flex justify-between items-center px-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                      Queue pile ({selectedFiles.length} file{selectedFiles.length > 1 ? "s" : ""})
                    </span>
                    <button
                      type="button"
                      onClick={() => setSelectedFiles([])}
                      className="text-[10px] hover:text-rose-500 transition font-bold text-slate-400 cursor-pointer"
                    >
                      Clear Queue
                    </button>
                  </div>
                  
                  <div className="max-h-40 overflow-y-auto border border-slate-100 rounded-xl divide-y divide-slate-50 bg-slate-50/20 pr-1">
                    {selectedFiles.map((file, idx) => (
                      <div key={idx} className="flex justify-between items-center p-2.5 text-xs">
                        <div className="flex items-center gap-2 truncate max-w-[80%]">
                          <File className="w-4 h-4 text-slate-400 flex-shrink-0" />
                          <span className="font-mono text-slate-600 truncate text-[11px]" title={file.relativePath}>
                            {file.relativePath}
                          </span>
                        </div>
                        <div className="flex items-center gap-2.5">
                          <span className="font-mono font-bold text-slate-400 text-[10px] bg-slate-100 px-1.5 py-0.5 rounded">
                            {formatSize(file.size)}
                          </span>
                          <button
                            type="button"
                            onClick={() => removeFile(idx)}
                            className="p-0.5 text-slate-350 hover:text-rose-500 rounded cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Multi File Folder custom naming field */}
                  {selectedFiles.length > 1 && (
                    <div className="space-y-1 text-left bg-blue-50/30 p-3 rounded-xl border border-blue-100/40">
                      <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block">Zip Archive Configuration</span>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="shared_archive_bundle"
                          value={folderName}
                          onChange={(e) => setFolderName(e.target.value.replace(/[^a-zA-Z0-9_\-]/g, ""))}
                          className="flex-1 bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-semibold focus:outline-none focus:border-blue-500"
                        />
                        <span className="text-[10px] font-mono font-bold text-slate-400 self-center">.zip</span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Advanced Link Options Panel */}
              <div className="border-t border-slate-100 pt-6 space-y-4">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono block">Custom Link Options</span>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Dynamic Password block */}
                  <div className="border border-slate-100 p-4 rounded-2xl bg-slate-50/30 space-y-3 text-left">
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={usePassword}
                        onChange={(e) => setUsePassword(e.target.checked)}
                        className="w-4 h-4 rounded border-slate-300 focus:ring-blue-400 text-blue-600"
                      />
                      <span className="text-xs font-bold text-slate-700 flex items-center gap-1">
                        <Lock className="w-3.5 h-3.5 text-slate-400" />
                        Toggle Password Shield
                      </span>
                    </label>
                    
                    <input
                      type="text"
                      disabled={!usePassword}
                      placeholder="Type secure pass phrase"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-white border border-slate-200 focus:border-blue-500 rounded-xl px-2.5 py-2 text-xs font-medium focus:outline-none transition disabled:opacity-40"
                    />
                  </div>

                  {/* Expiration Select block */}
                  <div className="border border-slate-100 p-4 rounded-2xl bg-slate-50/30 space-y-3 text-left">
                    <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      Set link expiration timeout
                    </span>
                    <select
                      value={expirationOption}
                      onChange={(e) => setExpirationOption(e.target.value)}
                      className="w-full bg-white border border-slate-200 focus:border-blue-500 rounded-xl px-2.5 py-2 text-xs font-semibold focus:outline-none transition cursor-pointer"
                    >
                      <option value="1">1 Hour (Highly Ephemeral)</option>
                      <option value="24">1 Day</option>
                      <option value="168">7 Days (Standard)</option>
                      <option value="never">Never (Persistent Cloud)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Upload Trigger Button */}
              <button
                type="button"
                onClick={handleTriggerUpload}
                disabled={selectedFiles.length === 0}
                className="w-full bg-slate-900 hover:bg-slate-800 disabled:opacity-45 text-white font-display font-medium text-sm py-4 rounded-2xl shadow-md flex items-center justify-center gap-2 transition duration-150 cursor-pointer disabled:cursor-not-allowed"
              >
                <span>Upload to Secure Cloud & Generate Link</span>
              </button>
            </motion.div>
          )}

          {/* Upload Progress/Status Monitor */}
          {(uploadState === "zipping" || uploadState === "uploading") && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="py-8 space-y-6 text-center"
            >
              {uploadState === "zipping" ? (
                <div className="space-y-4 max-w-md mx-auto text-left">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-slate-700 flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                      Bundling high-speed folder archive...
                    </span>
                    <span className="font-mono text-xs font-black text-blue-100/10 text-blue-600 font-bold">{zipPercent}%</span>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200/50">
                    <div 
                      className="h-full bg-blue-600 transition-all duration-150 ease-out shadow-[0_0_8px_rgba(37,99,235,0.4)]"
                      style={{ width: `${zipPercent}%` }}
                    />
                  </div>
                  
                  <p className="text-slate-400 text-[10px] leading-relaxed font-mono">
                    Using direct memory package streaming. Directories are indexed instantly with zero-CPU compression (STORE mode) to avoid system lag and expedite cloud transit.
                  </p>
                </div>
              ) : (
                <div className="space-y-5 max-w-md mx-auto text-left">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-700">Uploading stream to Google cloud...</span>
                    <span className="font-mono text-sm font-black text-blue-600">{uploadPercent}%</span>
                  </div>

                  {/* Outer Bar */}
                  <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-200/50">
                    <div 
                      className="h-full bg-blue-600 transition-all duration-150 ease-out shadow-[0_0_8px_rgba(37,99,235,0.4)]"
                      style={{ width: `${uploadPercent}%` }}
                    />
                  </div>

                  <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                    <span className="font-semibold text-slate-500">{formatSize(bytesUploaded)} / {formatSize(totalBytesToUpload)}</span>
                    <div className="flex gap-3 text-slate-500 font-bold">
                      <span>{uploadSpeed}</span>
                      {estimatedRemainingSeconds !== null && (
                        <span>ETA: {estimatedRemainingSeconds}s</span>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {/* Success Board Result Page */}
          {uploadState === "completed" && shareResult && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="py-4 space-y-6 text-center max-w-md mx-auto"
            >
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-full border border-emerald-100 inline-block animate-pulse">
                <Check className="w-8 h-8" />
              </div>
              
              <div>
                <h3 className="font-display font-black text-slate-800 text-lg tracking-tight">Cloud Link Instantly Ready!</h3>
                <p className="text-slate-400 text-xs mt-1 leading-relaxed">
                  The file coordinate has been successfully registered. Share this URL globally with any recipient.
                </p>
              </div>

              {/* Link copying box */}
              <div className="flex border border-slate-200/70 rounded-xl bg-slate-50 overflow-hidden text-xs">
                <input
                  type="text"
                  readOnly
                  value={shareResult.url}
                  className="flex-1 bg-transparent px-3.5 py-3 text-slate-600 font-mono focus:outline-none truncate"
                />
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="bg-slate-900 text-white font-bold px-4 hover:bg-slate-800 transition flex items-center gap-1.5 focus:outline-none cursor-pointer"
                >
                  {isLinkCopied ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Copy Link
                    </>
                  )}
                </button>
              </div>

              {/* Dynamic QR Code card */}
              <div className="bg-slate-50/50 rounded-2xl p-4 inline-block border border-slate-100 shadow-sm text-center">
                <canvas ref={qrCanvasRef} className="mx-auto border border-white rounded-xl shadow-3xs" />
                <span className="text-[9px] font-bold font-mono text-slate-400 mt-2 block uppercase tracking-wider">Recipient QR Access Code</span>
              </div>

              <button
                type="button"
                onClick={() => {
                  setUploadState("idle");
                  setShareResult(null);
                }}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 rounded-xl text-xs transition cursor-pointer"
              >
                Upload more files
              </button>
            </motion.div>
          )}

          {/* Error Board */}
          {uploadState === "error" && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="py-4 text-center space-y-5"
            >
              <div className="p-3 bg-rose-50 text-rose-500 border border-rose-100 rounded-full inline-block">
                <AlertCircle className="w-8 h-8" />
              </div>
              <div>
                <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight">Upload Session Halted</h4>
                <p className="text-rose-500 text-xs mt-1 max-w-sm mx-auto leading-relaxed">{errorMessage}</p>
              </div>
              <button
                type="button"
                onClick={() => setUploadState("idle")}
                className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-6 py-3 rounded-xl cursor-pointer"
              >
                Return & Retry Upload
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Senders Uploaded History and Analytics Panel */}
      {uploadedHistory.length > 0 && (
        <div className="space-y-4 text-left">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-black text-slate-800 text-sm uppercase tracking-wider flex items-center gap-1.5">
              <HardDrive className="w-4 h-4 text-slate-500" />
              My Cloud Share Console ({uploadedHistory.length} active)
            </h3>
            <span className="text-[10px] text-slate-400 italic">Self-managed telemetry logs</span>
          </div>

          <div className="bg-white border border-slate-100 rounded-3xl overflow-hidden shadow-sm divide-y divide-slate-50">
            {uploadedHistory.map((item) => (
              <div 
                key={item.id} 
                className={`p-4 hover:bg-slate-50/50 transition cursor-pointer select-none ${activeAnalyticsId === item.id ? "bg-slate-50/80 border-l-4 border-blue-500 pl-3" : ""}`}
                onClick={() => {
                  setActiveAnalyticsId(activeAnalyticsId === item.id ? null : item.id);
                }}
              >
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div className="min-w-0 pr-4">
                    <span className="font-bold text-xs text-slate-700 truncate block font-mono" title={item.name}>
                      {item.name}
                    </span>
                    <div className="flex items-center gap-3.5 text-[10px] text-slate-405 font-mono mt-1 text-slate-400">
                      <span>{formatSize(item.size)}</span>
                      <span>•</span>
                      <span>Uploaded: {new Date(item.uploadedAt).toLocaleDateString()}</span>
                      {item.expiration && item.expiration !== "never" && (
                        <>
                          <span>•</span>
                          <span className={`${Date.now() > new Date(item.expiration).getTime() ? "text-rose-500 font-bold" : "text-amber-600 font-semibold"}`}>
                            {Date.now() > new Date(item.expiration).getTime() ? "Expired" : `Expires: ${new Date(item.expiration).toLocaleDateString()}`}
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-start sm:self-center">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigator.clipboard.writeText(`${window.location.origin}/download/${item.id}`);
                        alert("Secure download link copied to clipboard!");
                      }}
                      className="p-1.5 rounded-lg border border-slate-200/60 bg-white hover:bg-slate-50 text-[10px] font-bold text-slate-500 flex items-center gap-1 cursor-pointer shadow-3xs"
                      title="Copy Share URL"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Link
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setActiveAnalyticsId(activeAnalyticsId === item.id ? null : item.id);
                      }}
                      className="p-1.5 rounded-lg border border-blue-100 bg-blue-50 hover:bg-blue-100 text-[10px] font-bold text-blue-600 flex items-center gap-1 cursor-pointer"
                      title="Toggle Analytics Dashboard"
                    >
                      <TrendingUp className="w-3.5 h-3.5 text-blue-500" />
                      Stats
                    </button>

                    <button
                      type="button"
                      onClick={(e) => handleDeleteHistoryItem(item.id, e)}
                      className="p-1.5 rounded-lg border border-slate-100 hover:border-rose-150 bg-slate-50 hover:bg-rose-50 text-slate-400 hover:text-rose-500 cursor-pointer transition shadow-3xs"
                      title="Remove from history"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Direct insertion inline of Analytics Panel on toggle expand! */}
                <AnimatePresence>
                  {activeAnalyticsId === item.id && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden mt-4 pt-4 border-t border-slate-100"
                      onClick={(e) => e.stopPropagation()} // Stop clicking within analytics closing it!
                    >
                      <AnalyticsPanel 
                        fileId={item.id} 
                        onClose={() => setActiveAnalyticsId(null)} 
                      />
                    </motion.div>
                  )}
                </AnimatePresence>

              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
