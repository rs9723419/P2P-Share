/**
 * Utility functions for Google Drive uploads and share configuration
 */

export interface GoogleDriveUploadResponse {
  id: string;
  name: string;
  mimeType: string;
}

/**
 * Uploads a file to Google Drive using multipart upload.
 * Provides live progress callbacks via XMLHttpRequest upload event hooks.
 */
export function uploadFileToDrive(
  file: File,
  accessToken: string,
  onProgress?: (percent: number) => void
): Promise<GoogleDriveUploadResponse> {
  return new Promise((resolve, reject) => {
    const boundary = "drive_file_multipart_boundary_xyz";
    const header = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n`;
    const metadata = JSON.stringify({
      name: file.name,
      mimeType: file.type || "application/octet-stream",
    });
    const middle = `\r\n--${boundary}\r\nContent-Type: ${file.type || "application/octet-stream"}\r\n\r\n`;
    const footer = `\r\n--${boundary}--`;

    const headerBlob = new Blob([header], { type: "text/plain" });
    const metadataBlob = new Blob([metadata], { type: "application/json" });
    const middleBlob = new Blob([middle], { type: "text/plain" });
    const footerBlob = new Blob([footer], { type: "text/plain" });

    // Creates composite blob to stream files without duplicate buffering memory constraints
    const body = new Blob([headerBlob, metadataBlob, middleBlob, file, footerBlob], {
      type: `multipart/related; boundary=${boundary}`,
    });

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart");
    xhr.setRequestHeader("Authorization", `Bearer ${accessToken}`);

    if (onProgress && xhr.upload) {
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
          const percent = Math.round((e.loaded / e.total) * 100);
          onProgress(percent);
        }
      };
    }

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const res = JSON.parse(xhr.responseText);
          resolve(res);
        } catch (err) {
          reject(new Error("Unable to parse Google Drive API upload response."));
        }
      } else {
        reject(new Error(`Drive upload status error (${xhr.status}): ${xhr.responseText}`));
      }
    };

    xhr.onerror = () => {
      reject(new Error("Network transfer exception failed to upload chunks to Google Drive."));
    };

    xhr.send(body);
  });
}

/**
 * Changes a Google Drive file's permission to be publicly readable by 'anyone with the link'.
 */
export async function makeFileShareable(fileId: string, accessToken: string): Promise<void> {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}/permissions`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      role: "reader",
      type: "anyone",
    }),
  });

  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`Failed to grant public access for file: ${errorText}`);
  }
}

/**
 * Generates the web view URL of a Google Drive file.
 */
export function constructDriveShareLink(fileId: string): string {
  return `https://drive.google.com/file/d/${fileId}/view?usp=sharing`;
}
