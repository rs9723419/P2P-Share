import React from "react";
import { Shield, Zap, ServerOff } from "lucide-react";

export default function Header() {
  return (
    <header className="text-center py-6 border-b border-slate-100 mb-8">
      <div className="inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-xs font-semibold tracking-wide border border-emerald-100 mb-4 animate-pulse">
        <Shield className="w-3.5 h-3.5" />
        PEER-TO-PEER ENCRYPTED (E2EE)
      </div>
      
      <h1 className="text-4xl md:text-5xl font-display font-extrabold text-slate-900 tracking-tight">
        Direct <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">P2P</span> Share
      </h1>
      
      <p className="mt-2.5 text-sm md:text-base text-slate-500 max-w-lg mx-auto font-sans leading-relaxed">
        High-speed, browser-to-browser secure file transfer. Files stream directly between devices and never touch our servers.
      </p>

      <div className="flex justify-center items-center gap-5 mt-5 text-xs font-medium text-slate-500 font-sans">
        <span className="flex items-center gap-1.5" title="Direct WebRTC Connection">
          <Zap className="w-4 h-4 text-amber-500" />
          Ultra-Fast Send
        </span>
        <span className="w-1 h-1 bg-slate-300 rounded-full" />
        <span className="flex items-center gap-1.5" title="Zero Server File Storage">
          <ServerOff className="w-4 h-4 text-rose-500" />
          No Server Clones (Privacy Safe)
        </span>
      </div>
    </header>
  );
}
