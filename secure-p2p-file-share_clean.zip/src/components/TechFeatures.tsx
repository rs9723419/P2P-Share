import React from "react";
import { ShieldAlert, Cpu, Network, FolderGit } from "lucide-react";

export default function TechFeatures() {
  const cards = [
    {
      icon: <Network className="w-5 h-5 text-blue-600" />,
      title: "Direct Data Channels",
      description: "Data flows over modern WebRTC PeerConnections without hitting cloud storage. No upload caps, no queueing."
    },
    {
      icon: <ShieldAlert className="w-5 h-5 text-emerald-600" />,
      title: "End-to-End DTLS",
      description: "Protected with military-grade DTLS & SRTP encryptions. Impossible for any man-in-the-middle to read your files."
    },
    {
      icon: <Cpu className="w-5 h-5 text-indigo-600" />,
      title: "Chuncked Memory Care",
      description: "Files are sliced into binary ArrayBuffers sequentially to keep memory usage low, supporting gigabyte transfers."
    },
    {
      icon: <FolderGit className="w-5 h-5 text-amber-600" />,
      title: "Folder Tree Persistence",
      description: "Supports dragging whole folders. Recipient streams the index, producing a perfectly structured .zip download."
    }
  ];

  return (
    <div className="mt-12 pt-8 border-t border-slate-100">
      <h3 className="text-center text-xs font-semibold uppercase tracking-wider text-slate-400 mb-6 font-display">
        PEER-TO-PEER INDUSTRIAL SECURITY SPECIFICATION
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card, idx) => (
          <div key={idx} className="bg-white border border-slate-100 p-4 rounded-xl shadow-xs hover:shadow-md transition duration-200">
            <div className="p-2 bg-slate-50 rounded-lg inline-block mb-3">
              {card.icon}
            </div>
            <h4 className="font-display font-bold text-slate-800 text-sm">{card.title}</h4>
            <p className="font-sans text-xs text-slate-500 mt-1 leading-relaxed">{card.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
