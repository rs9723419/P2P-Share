import React, { useState, useEffect, useRef } from "react";
import { Download, Loader2, ArrowRight, ShieldCheck, X, RefreshCw, FolderSearch, FileSpreadsheet, Camera } from "lucide-react";
import JSZip from "jszip";
import { FileMetadata, TransferStats } from "../types";
import { getSignalingServerUrl } from "../lib/signaling";
import { Html5Qrcode } from "html5-qrcode";

export default function ReceiveSection() {
  const [enteredPin, setEnteredPin] = useState("");
  
  // Connection states
  // "idle" | "joining" | "awaiting_accept" | "connecting_peer" | "transferring" | "compiling" | "completed" | "error"
  const [receiveState, setReceiveState] = useState<
    "idle" | "joining" | "awaiting_accept" | "connecting_peer" | "transferring" | "compiling" | "completed" | "error"
  >("idle");
  const [errorMessage, setErrorMessage] = useState("");

  // Metadata received about files
  const [fileMeta, setFileMeta] = useState<FileMetadata | null>(null);
  const fileMetaRef = useRef<FileMetadata | null>(null);

  // Transfer stats
  const [stats, setStats] = useState<TransferStats>({
    speedBytesPerSec: 0,
    percent: 0,
    bytesSentOrReceived: 0,
    totalBytes: 0,
    elapsedSeconds: 0,
    estimatedRemainingSeconds: 0,
    currentFileName: "",
    currentFileIndex: 0
  });

  // WebRTC & WebSockets Refs
  const wsRef = useRef<WebSocket | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const dataChannelRef = useRef<RTCDataChannel | null>(null);

  // QR Code Camera scanner state
  const [isScanning, setIsScanning] = useState(false);
  const [scanMessage, setScanMessage] = useState("");
  const qrScannerRef = useRef<Html5Qrcode | null>(null);

  // Buffer state
  const isReceiveActiveRef = useRef(false);
  const transferStartTimeRef = useRef(0);
  const bytesReceivedRef = useRef(0);
  const lastStateUpdateRef = useRef(0);

  // Buffer for currently receiving file chunks
  const receivedChunksRef = useRef<Blob[]>([]);
  const currentFileMetaRef = useRef<{ name: string; relativePath: string; size: number; index: number; fileType: string } | null>(null);
  
  // Accumulated completed files list for directory download compiles
  const completedFilesRef = useRef<{ name: string; relativePath: string; blob: Blob }[]>([]);

  const iceServers = [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
    { urls: "stun:stun2.l.google.com:19302" },
    { urls: "stun:stun3.l.google.com:19302" }
  ];

  // Self-executing PIN check in URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlPin = params.get("pin");
    if (urlPin && /^\d{6}$/.test(urlPin)) {
      setEnteredPin(urlPin);
      handleJoinByPin(urlPin);
    }
  }, []);

  // Wrap cleanups on unmount
  useEffect(() => {
    return () => {
      cleanupConnection();
      stopCameraScanner();
    };
  }, []);

  const cleanupConnection = () => {
    isReceiveActiveRef.current = false;
    receivedChunksRef.current = [];
    currentFileMetaRef.current = null;
    
    if (dataChannelRef.current) {
      dataChannelRef.current.close();
      dataChannelRef.current = null;
    }
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
  };

  const startCameraScanner = async () => {
    setIsScanning(true);
    setScanMessage("Initializing device camera, please wait...");
    // Let React render container
    setTimeout(async () => {
      try {
        const scanner = new Html5Qrcode("qr-reader");
        qrScannerRef.current = scanner;
        
        await scanner.start(
          { facingMode: "environment" },
          {
            fps: 10,
            qrbox: (width, height) => {
              const min = Math.min(width, height);
              const size = Math.floor(min * 0.7);
              return { width: size, height: size };
            }
          },
          (decodedText) => {
            // Found secure P2P QR
            setScanMessage("Valid QR Code detected!");
            
            // Extract trailing 6-digit pin from string url or direct inputs
            const match = decodedText.match(/(?:pin=)?(\d{6})/i);
            if (match && match[1]) {
              const code = match[1];
              setEnteredPin(code);
              stopCameraScanner();
              handleJoinByPin(code);
            } else {
              setScanMessage("QR code scanned but no valid 6-digit PIN was found inside.");
            }
          },
          () => {
            // Keep looking silently
          }
        );
        setScanMessage("Point camera towards sender's QR code.");
      } catch (err: any) {
        console.error("Camera access failed:", err);
        setScanMessage("Could not access camera. Ensure tab has camera permissions.");
      }
    }, 150);
  };

  const stopCameraScanner = async () => {
    if (qrScannerRef.current) {
      try {
        if (qrScannerRef.current.isScanning) {
          await qrScannerRef.current.stop();
        }
      } catch (e) {
        console.warn("Failed to halt scanner thread:", e);
      }
      qrScannerRef.current = null;
    }
    setIsScanning(false);
    setScanMessage("");
  };

  const handleJoinByPin = (targetPin?: string) => {
    const pinToUse = (targetPin || enteredPin).trim();
    if (!/^\d{6}$/.test(pinToUse)) {
      setErrorMessage("Please enter a valid 6-digit numeric security PIN.");
      setReceiveState("error");
      return;
    }

    setReceiveState("joining");
    setErrorMessage("");
    completedFilesRef.current = [];

    try {
      const wsUrl = getSignalingServerUrl();
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        ws.send(JSON.stringify({ type: "join-room", pin: pinToUse }));
      };

      ws.onmessage = async (event) => {
        try {
          const payload = JSON.parse(event.data);

          if (payload.type === "joined") {
            // Joined room, if file info is ready, setup accept phase
            if (payload.fileInfo) {
              setFileMeta(payload.fileInfo);
              fileMetaRef.current = payload.fileInfo;
              setReceiveState("awaiting_accept");

              // AUTO-DOWNLOAD: if the user arrived via direct link/QR-code, instantly start the download
              const params = new URLSearchParams(window.location.search);
              if (params.get("pin")) {
                setTimeout(() => {
                  handleAcceptTransfer(payload.fileInfo);
                }, 300);
              }
            } else {
              // Wait for set-file-info signal from the sender index
              setReceiveState("joining");
            }
          } 
          
          else if (payload.type === "file-info") {
            setFileMeta(payload.fileInfo);
            fileMetaRef.current = payload.fileInfo;
            setReceiveState("awaiting_accept");

            // AUTO-DOWNLOAD: if the user arrived via direct link/QR-code, instantly start the download
            const params = new URLSearchParams(window.location.search);
            if (params.get("pin")) {
              setTimeout(() => {
                handleAcceptTransfer(payload.fileInfo);
              }, 300);
            }
          } 
          
          else if (payload.type === "signal") {
            if (peerConnectionRef.current) {
              const { sdp, candidate } = payload.data;
              if (sdp && sdp.type === "offer") {
                await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(sdp));
                console.log("[WebRTC] RTC Offer applied. Constructing Answer...");
                
                const answer = await peerConnectionRef.current.createAnswer();
                await peerConnectionRef.current.setLocalDescription(answer);

                ws.send(JSON.stringify({
                  type: "signal",
                  data: { sdp: answer }
                }));
              } else if (candidate) {
                await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(candidate))
                  .catch(e => console.warn("[WebRTC] Error adding candidate", e));
              }
            }
          } 
          
          else if (payload.type === "host-disconnected") {
            if (isReceiveActiveRef.current) {
              setErrorMessage("The sender terminated the connection or closed their browser.");
              setReceiveState("error");
              cleanupConnection();
            } else {
              setErrorMessage(`PIN room ${enteredPin} has expired or the host disconnected.`);
              setReceiveState("error");
              cleanupConnection();
            }
          } 
          
          else if (payload.type === "transfer-cancelled") {
            setErrorMessage("Direct transfer channel has been cancelled by sender.");
            setReceiveState("error");
            cleanupConnection();
          } 
          
          else if (payload.type === "error") {
            setErrorMessage(payload.message || "Could not find matching room.");
            setReceiveState("error");
            cleanupConnection();
          }
        } catch (err) {
          // Binary message or payload parse fail
        }
      };

      ws.onclose = () => {
        if (receiveState !== "completed" && receiveState !== "error" && isReceiveActiveRef.current) {
          setErrorMessage("Loss of communication signaling lines.");
          setReceiveState("error");
          cleanupConnection();
        }
      };

      ws.onerror = () => {
        setErrorMessage("Network connection exception routing room.");
        setReceiveState("error");
        cleanupConnection();
      };

    } catch (e: any) {
      setErrorMessage(e.message || "Failed to initialize receiving websocket.");
      setReceiveState("error");
    }
  };

  // Triggers WebRTC Handshakes once user accepts File Metadata
  const handleAcceptTransfer = async (metaOverride?: FileMetadata) => {
    const activeMeta = metaOverride || fileMeta || fileMetaRef.current;
    if (!activeMeta) return;

    if (!fileMeta) setFileMeta(activeMeta);
    if (!fileMetaRef.current) fileMetaRef.current = activeMeta;

    setReceiveState("connecting_peer");
    
    try {
      const pc = new RTCPeerConnection({ iceServers });
      peerConnectionRef.current = pc;

      // Handle candidate exchange
      pc.onicecandidate = (event) => {
        if (event.candidate && wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
          wsRef.current.send(JSON.stringify({
            type: "signal",
            data: { candidate: event.candidate }
          }));
        }
      };

      // Receives Data Channel from host
      pc.ondatachannel = (event) => {
        const dc = event.channel;
        dataChannelRef.current = dc;
        dc.binaryType = "arraybuffer"; // vital: read chunks as raw binary arraybuffers

        dc.onopen = () => {
          console.log("[WebRTC] Receiver connection linked. Ready to stream data blocks!");
          isReceiveActiveRef.current = true;
          setReceiveState("transferring");
          transferStartTimeRef.current = Date.now();
          bytesReceivedRef.current = 0;
          lastStateUpdateRef.current = 0;
        };

        dc.onmessage = async (msgEvent) => {
          // Check if data is control command (String) or file chunk bytes (ArrayBuffer)
          if (typeof msgEvent.data === "string") {
            try {
              const cmd = JSON.parse(msgEvent.data);
              
              if (cmd.type === "meta") {
                // Confirm overall details
                setStats(p => ({
                  ...p,
                  totalBytes: cmd.totalSize,
                  bytesSentOrReceived: 0,
                  percent: 0,
                  currentFileIndex: 0
                }));
              } 
              
              else if (cmd.type === "file-start") {
                currentFileMetaRef.current = {
                  name: cmd.relativePath.split("/").pop() || "file",
                  relativePath: cmd.relativePath,
                  size: cmd.size,
                  index: cmd.index,
                  fileType: cmd.fileType || "application/octet-stream"
                };
                receivedChunksRef.current = []; // empty slice collector
              } 
              
              else if (cmd.type === "file-end") {
                const meta = currentFileMetaRef.current;
                if (meta) {
                  const compiledFileBlob = new Blob(receivedChunksRef.current, { type: meta.fileType });
                  completedFilesRef.current.push({
                    name: meta.name,
                    relativePath: meta.relativePath,
                    blob: compiledFileBlob
                  });
                }
                currentFileMetaRef.current = null;
                receivedChunksRef.current = [];
              } 
              
              else if (cmd.type === "done") {
                // All blocks successfully streamed! Compile download triggers
                setReceiveState("compiling");
                await finalizeRecipientDownloads();
              }
            } catch (err) {
              console.error("Failed to parse RTC control string:", err);
            }
          } 
          
          // Binary array chunk block
          else if (msgEvent.data instanceof ArrayBuffer) {
            const buffer = msgEvent.data;
            receivedChunksRef.current.push(new Blob([buffer]));
            bytesReceivedRef.current += buffer.byteLength;

            // Stats optimization: update UI state 4 times a second max (250ms)
            const now = Date.now();
            if (now - lastStateUpdateRef.current > 250) {
              const elapsed = (now - transferStartTimeRef.current) / 1000;
              const cumulativeRecv = bytesReceivedRef.current;
              const totalBytes = stats.totalBytes || fileMetaRef.current?.size || 0;
              const speed = elapsed > 0 ? cumulativeRecv / elapsed : 0;
              const remainingVal = totalBytes - cumulativeRecv;
              const remainingSecs = speed > 50 ? Math.ceil(remainingVal / speed) : 9999;
              const percent = totalBytes > 0 ? Math.min(100, Math.round((cumulativeRecv / totalBytes) * 100)) : 0;

              setStats({
                speedBytesPerSec: speed,
                percent,
                bytesSentOrReceived: cumulativeRecv,
                totalBytes,
                elapsedSeconds: Math.round(elapsed),
                estimatedRemainingSeconds: remainingSecs,
                currentFileName: currentFileMetaRef.current?.name || "",
                currentFileIndex: currentFileMetaRef.current?.index || 0
              });
              lastStateUpdateRef.current = now;
            }
          }
        };

        dc.onclose = () => {
          if (receiveState === "transferring") {
            setErrorMessage("Sender terminated browser tab, severing Webrtc channel.");
            setReceiveState("error");
            cleanupConnection();
          }
        };
      };

    } catch (err: any) {
      setErrorMessage("WebRTC init error: " + (err.message || err));
      setReceiveState("error");
      cleanupConnection();
    }
  };

  // Compile individual downloaded BLOBS or zip folder as structured directory tree
  const finalizeRecipientDownloads = async () => {
    try {
      const files = completedFilesRef.current;
      if (files.length === 0) {
        setErrorMessage("Received zero file payload compiled bytes.");
        setReceiveState("error");
        cleanupConnection();
        return;
      }

      if (files.length === 1 && !fileMeta?.isFolder) {
        // Individual single file downloaded: Trigger direct local file write saves
        const singleFile = files[0];
        const url = URL.createObjectURL(singleFile.blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = singleFile.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      } else {
        // Directory folder tree downloaded: Zip them with jszip maintaining nested folders
        const zip = new JSZip();
        for (const file of files) {
          zip.file(file.relativePath, file.blob);
        }
        
        const zipOutputBlob = await zip.generateAsync({ type: "blob" });
        const url = URL.createObjectURL(zipOutputBlob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `${fileMeta?.name || "secure_p2p_folder"}.zip`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }

      setReceiveState("completed");
      cleanupConnection();
    } catch (e: any) {
      setErrorMessage("Error compilation download file builder: " + (e.message || e));
      setReceiveState("error");
      cleanupConnection();
    }
  };

  const handleCancel = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: "cancel-transfer", reason: "Recipient cancelled" }));
    }
    setReceiveState("idle");
    cleanupConnection();
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const formatSpeed = (bytesPerSec: number) => {
    const mb = bytesPerSec / (1024 * 1024);
    if (mb >= 1) return `${mb.toFixed(1)} MB/s`;
    const kb = bytesPerSec / 1024;
    return `${kb.toFixed(1)} KB/s`;
  };

  const formatTime = (secs: number) => {
    if (secs > 3600) {
      const h = Math.floor(secs / 3600);
      const m = Math.floor((secs % 3600) / 60);
      return `${h}h ${m}m`;
    }
    if (secs >= 60) {
      const m = Math.floor(secs / 60);
      const s = secs % 60;
      return `${m}m ${s}s`;
    }
    return `${secs}s`;
  };

  return (
    <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xl max-w-2xl mx-auto">
      
      {/* 1. IDLE/PIN ENTRY MODE */}
      {receiveState === "idle" && (
        <div className="space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-display font-black text-slate-800 text-lg">Receive Files & Folders</h3>
            <p className="text-xs text-slate-500 mt-1">
              Enter the unique 6-digit PIN or scan the sender's QR code to instantly start secure direct download.
            </p>
          </div>

          {isScanning ? (
            <div className="space-y-4 animate-fade-in">
              <div className="text-center">
                <span className="text-[10px] bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full font-bold uppercase tracking-wider animate-pulse inline-block mb-2">
                  Scanning device camera feed
                </span>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">{scanMessage}</p>
              </div>

              {/* QR Reader viewport container */}
              <div className="relative max-w-[320px] w-full mx-auto aspect-square rounded-2xl overflow-hidden border border-slate-200 bg-slate-900 shadow-lg group">
                <div id="qr-reader" className="w-full h-full" />
                {/* Visual scan pulse frame */}
                <div className="absolute inset-x-4 top-1/2 h-0.5 bg-emerald-500 opacity-75 shadow-lg shadow-emerald-400 animate-pulse pointer-events-none" />
              </div>

              <button
                type="button"
                onClick={stopCameraScanner}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-3 rounded-2xl text-xs transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <X className="w-4 h-4 text-slate-500" />
                Cancel Camera Scan & Enter PIN
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex flex-col items-center">
                <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-2">ENTER 6-DIGIT CODE</span>
                <input
                  id="receive-pin-input"
                  type="text"
                  pattern="\d*"
                  maxLength={6}
                  placeholder="000000"
                  value={enteredPin}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, "");
                    setEnteredPin(val);
                  }}
                  className="font-mono text-center text-4xl block w-56 font-black tracking-widest text-[#1e293b] placeholder-slate-200 border-2 border-slate-200 focus:border-blue-500 bg-slate-50/50 py-3.5 rounded-2xl focus:outline-none transition-all duration-200"
                />
                <p className="text-slate-400 text-[10px] uppercase font-mono tracking-wide mt-2">
                  Picks encryption coordinate pins
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  id="submit-pin-btn"
                  onClick={() => handleJoinByPin()}
                  disabled={enteredPin.length !== 6}
                  className="flex-1 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-display font-bold py-3.5 rounded-2xl shadow-lg flex items-center justify-center gap-2 transition duration-200 cursor-pointer disabled:cursor-not-allowed"
                >
                  Connect
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={startCameraScanner}
                  className="bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 font-display font-bold px-5 rounded-2xl shadow-xs flex items-center justify-center gap-2 transition duration-200 cursor-pointer"
                  title="Scan QR Code with Camera"
                >
                  <Camera className="w-5 h-5" />
                  <span className="hidden sm:inline">Scan QR Code</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. JOINING THE SIGNALING ROOM */}
      {receiveState === "joining" && (
        <div className="py-12 text-center space-y-4">
          <Loader2 className="w-10 h-10 text-slate-900 animate-spin mx-auto animate-reverse" />
          <h3 className="font-display font-bold text-slate-800 text-lg">Locating Security PIN Room...</h3>
          <p className="text-slate-400 text-xs max-w-sm mx-auto">
            Resolving room coordinates for PIN <strong>{enteredPin}</strong>. Handshaking websocket details, wait a brief second for host connection response.
          </p>
          <button
            onClick={() => { setReceiveState("idle"); cleanupConnection(); }}
            className="text-xs text-rose-500 hover:underline font-semibold mt-4 block mx-auto"
          >
            Cancel Connect lookup
          </button>
        </div>
      )}

      {/* 3. AWAITING ACCEPT */}
      {receiveState === "awaiting_accept" && fileMeta && (
        <div className="space-y-6">
          <div className="border-b border-slate-100 pb-3 text-center">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-full inline-block mb-3 border border-emerald-100 shadow-sm animate-pulse">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <h3 className="font-display font-black text-slate-800 text-xl tracking-tight">Direct P2P Link Formed</h3>
            <p className="text-slate-400 text-xs mt-1 leading-relaxed">
              We connected successfully to the sender browser. They are ready to stream the following files directly over encrypted channel.
            </p>
          </div>

          {/* Metadata Summary Card */}
          <div className="bg-slate-50 border border-slate-100 p-5 rounded-2xl space-y-4">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-white rounded-xl border border-slate-200/60 shadow-xs flex items-center justify-center text-blue-600 mt-1">
                {fileMeta.isFolder ? <FolderSearch className="w-7 h-7" /> : <FileSpreadsheet className="w-7 h-7" />}
              </div>
              <div className="flex-1 truncate">
                <span className="text-[10px] text-slate-400 block uppercase tracking-wide font-bold">INCOMING STREAM PAYLOAD</span>
                <span className="font-display font-bold text-slate-800 block text-base truncate" title={fileMeta.name}>
                  {fileMeta.name}
                </span>
                <p className="text-slate-500 text-xs mt-0.5 font-mono">
                  Total Size: <strong>{formatSize(fileMeta.size)}</strong> {fileMeta.isFolder && `• Directory Folder (${fileMeta.fileCount} nested files)`}
                </p>
              </div>
            </div>
          </div>

          <button
            id="accept-transfer-btn"
            onClick={handleAcceptTransfer}
            className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-display font-bold py-3.5 rounded-2xl shadow-md shadow-emerald-100 flex items-center justify-center gap-2 transition duration-200 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            Accept & Stream Direct Download (P2P)
          </button>

          <button
            onClick={handleCancel}
            className="w-full text-center text-xs text-slate-400 hover:text-rose-500 hover:underline font-semibold"
          >
            Refuse & Disconnect
          </button>
        </div>
      )}

      {/* 4. CONNECTING PEER PORT TRAVERSALS */}
      {receiveState === "connecting_peer" && (
        <div className="py-12 text-center space-y-4">
          <Loader2 className="w-10 h-10 text-emerald-500 animate-spin mx-auto" />
          <h3 className="font-display font-bold text-slate-800 text-lg">Exchanging DTLS Secure Keys...</h3>
          <p className="text-slate-400 text-xs max-w-sm mx-auto">
            Arranging symmetric cryptographic session parameters on the direct browser socket pipeline pathway. Bypassing intermediaries.
          </p>
        </div>
      )}

      {/* 5. ACTIVE TRANSFERPING BLOCKS */}
      {receiveState === "transferring" && (
        <div className="space-y-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-md">
                STREAMING ENCRYPTED BLOCKS INWARDS
              </span>
              <h3 className="font-display font-extrabold text-slate-800 text-lg mt-2 truncate max-w-md">
                {fileMeta?.name}
              </h3>
            </div>
            <span className="font-mono text-3xl font-black text-emerald-600">{stats.percent}%</span>
          </div>

          <div className="space-y-2">
            <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
              <div
                id="recv-progress-bar"
                className="bg-gradient-to-r from-emerald-500 to-teal-500 h-full rounded-full transition-all duration-300"
                style={{ width: `${stats.percent}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-slate-500 font-sans">
              <span>{formatSize(stats.bytesSentOrReceived)} of {formatSize(stats.totalBytes || fileMeta?.size || 0)} received</span>
              <span className="font-semibold text-slate-700">File {stats.currentFileIndex + 1} of {fileMeta?.fileCount || 1}</span>
            </div>
          </div>

          {/* Speed & Remaining Time stats board */}
          <div id="recv-stats-grid" className="grid grid-cols-3 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-100 font-mono">
            <div className="text-center md:text-left">
              <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wide">SPEED</span>
              <span className="text-sm font-bold text-slate-800 block mt-0.5">{formatSpeed(stats.speedBytesPerSec)}</span>
            </div>
            <div className="text-center md:text-left border-x border-slate-200">
              <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wide">ELAPSED TIME</span>
              <span className="text-sm font-bold text-slate-800 block mt-0.5">{formatTime(stats.elapsedSeconds)}</span>
            </div>
            <div className="text-center md:text-left">
              <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wide">REMAINING (EST)</span>
              <span className="text-sm font-bold text-slate-800 block mt-0.5">
                {stats.estimatedRemainingSeconds === 9999 ? "calculating..." : formatTime(stats.estimatedRemainingSeconds)}
              </span>
            </div>
          </div>

          {/* Active File Segment detail row */}
          <div className="flex items-center gap-3 p-3 bg-emerald-50/50 border border-emerald-100 rounded-xl">
            <Loader2 className="w-4 h-4 text-emerald-600 animate-spin" />
            <div className="text-xs truncate max-w-sm flex-1">
              <span className="text-slate-400 block text-[9px] uppercase tracking-wider font-bold">DESERIALIZING BLOCK STREAM</span>
              <span className="text-slate-700 font-mono font-bold truncate block">{stats.currentFileName || "Awaiting incoming file blocks..."}</span>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <span className="text-[10px] text-slate-400 max-w-xs leading-relaxed">
              DO NOT CLOSE this page while the stream is active, or the download pipeline will crash instantly.
            </span>
            <button
              onClick={handleCancel}
              className="text-xs text-rose-500 hover:text-rose-700 font-bold hover:underline"
            >
              Cancel Download
            </button>
          </div>
        </div>
      )}

      {/* 6. COMPILING AND WRITING */}
      {receiveState === "compiling" && (
        <div className="py-12 text-center space-y-4">
          <Loader2 className="w-10 h-10 text-amber-500 animate-spin mx-auto" />
          <h3 className="font-display font-bold text-slate-800 text-lg">Assembling folder structure...</h3>
          <p className="text-slate-400 text-xs max-w-sm mx-auto">
            Constructing binary maps and assembling zipped directories locally within browser storage. This uses zero server processing, compiling purely on your CPU.
          </p>
        </div>
      )}

      {/* 7. COMPLETED SUCCESS SCREEN */}
      {receiveState === "completed" && (
        <div className="py-8 text-center space-y-6">
          <div className="p-4 bg-emerald-50 text-emerald-600 rounded-full border border-emerald-100 inline-block shadow-sm">
            <ShieldCheck className="w-10 h-10" />
          </div>

          <div>
            <h3 className="font-display font-black text-slate-800 text-xl tracking-tight">E2EE Download Completed</h3>
            <p className="text-slate-400 text-xs mt-1 md:px-12 leading-relaxed">
              Your files have been successfully streamed, decoded, and local file storage write completed over fully secured, encrypted channels.
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl inline-block text-xs font-semibold text-slate-600 max-w-sm">
            Retrieved: {fileMeta?.name} ({formatSize(fileMeta?.size || 0)})
          </div>

          <div className="pt-6 border-t border-slate-100 flex justify-center gap-3">
            <button
              id="receive-new-files-btn"
              onClick={() => {
                setEnteredPin("");
                setFileMeta(null);
                setReceiveState("idle");
                cleanupConnection();
              }}
              className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs px-6 py-3 rounded-xl flex items-center gap-2 transition cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              Receive New Files
            </button>
          </div>
        </div>
      )}

      {/* 8. TUNNEL EXCEPTION ERRORS */}
      {receiveState === "error" && (
        <div className="py-8 text-center space-y-6">
          <div className="p-4 bg-rose-50 text-rose-600 rounded-full border border-rose-100 inline-block">
            <X className="w-10 h-10" />
          </div>

          <div>
            <h3 className="font-display font-black text-slate-800 text-xl tracking-tight">Receiver Tunnel Exception</h3>
            <p className="text-rose-600 text-xs font-semibold mt-2 bg-rose-50 p-3 rounded-xl max-w-md mx-auto border border-rose-100/60 leading-relaxed font-mono">
              {errorMessage || "Connection failed. Please ensure the sender has not closed their browser and you entered the correct PIN."}
            </p>
          </div>

          <div className="pt-6 border-t border-slate-100 flex justify-center gap-3">
            <button
              onClick={() => {
                setReceiveState("idle");
                cleanupConnection();
              }}
              className="bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs px-6 py-3 rounded-xl flex items-center gap-2 transition cursor-pointer"
            >
              Return to PIN screen
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
