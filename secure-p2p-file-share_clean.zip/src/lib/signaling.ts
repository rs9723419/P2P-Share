/**
 * Centralized signaling and URL resolving logic for private room orchestration
 */

const PUBLIC_PRE_RELEASE_HOST = "ais-pre-iff5tvivbdevaqznui3o5k-139233232935.asia-east1.run.app";

/**
 * Returns the correct WebSocket signaling server URL.
 * Automatically handles routing when the app is in the AI Studio Dev sandbox or deployed to high-performance servers like Vercel.
 */
export const getSignalingServerUrl = (): string => {
  const host = window.location.host;
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";

  const isCloudRunHost = host.includes("asia-east1.run.app");
  const isLocalHost = host.includes("localhost") || host.includes("127.0.0.1") || host.includes("0.0.0.0");

  // If running on a server-hosting platform (Cloud Run or Localhouse), connect same-origin
  if (isCloudRunHost || isLocalHost) {
    return `${protocol}//${host}`;
  }

  // Deployed to serverless static environments (Vercel, Netlify, etc.) -> use Cloud Run backend
  return `wss://${PUBLIC_PRE_RELEASE_HOST}`;
};

/**
 * Resolves a guest-accessible URL pattern to share with recipients.
 */
export const getPublicShareUrl = (currentPin: string): string => {
  const origin = window.location.origin;
  return `${origin}/?pin=${currentPin}`;
};
