import React, { useState, useEffect } from "react";
import { 
  X, 
  TrendingUp, 
  Smartphone, 
  Monitor, 
  Compass, 
  BarChart2, 
  Clock, 
  Users, 
  RefreshCw,
  Info
} from "lucide-react";
import { doc, getDoc, onSnapshot } from "firebase/firestore";
import { db } from "../lib/firebase";
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar,
  Legend
} from "recharts";
import { motion } from "motion/react";

interface AnalyticsPanelProps {
  fileId: string;
  onClose: () => void;
}

export default function AnalyticsPanel({ fileId, onClose }: AnalyticsPanelProps) {
  const [fileData, setFileData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Realtime snapshot listener to show downloads updating on-the-fly!
    const fileRef = doc(db, "shared_files", fileId);
    
    const unsubscribe = onSnapshot(fileRef, (snapshot) => {
      if (snapshot.exists()) {
        setFileData(snapshot.data());
        setError(null);
      } else {
        setError("This shared file record count data was not found in the database.");
      }
      setLoading(false);
    }, (err) => {
      console.error("Firestore listening leak:", err);
      setError("Database stream connection failed.");
      setLoading(false);
    });

    return () => unsubscribe();
  }, [fileId]);

  if (loading) {
    return (
      <div className="p-8 bg-white border border-slate-100 rounded-3xl text-center space-y-3 animate-fade-in shadow-xl">
        <RefreshCw className="w-8 h-8 animate-spin mx-auto text-blue-600" />
        <p className="text-xs text-slate-500 font-medium">Gathering secure download telemetry streams...</p>
      </div>
    );
  }

  if (error || !fileData) {
    return (
      <div className="p-8 bg-white border border-slate-100 rounded-3xl text-center space-y-4 shadow-xl">
        <p className="text-sm font-semibold text-rose-500">{error || "No data available."}</p>
        <button
          onClick={onClose}
          className="bg-slate-900 text-white font-semibold text-xs px-4 py-2 rounded-xl"
        >
          Close Panel
        </button>
      </div>
    );
  }

  const logs = fileData.analytics || [];
  const totalDownloads = fileData.downloadCount || 0;

  // 1. Process Timeline Data (Group logs by date or simple hours)
  const getTimelineData = () => {
    // Group logs by Date string (e.g. "Jun 16")
    const counts: { [key: string]: number } = {};
    
    // Seed with last 5 days to ensure chart looks beautiful even if empty
    const now = new Date();
    for (let i = 4; i >= 0; i--) {
      const d = new Date();
      d.setDate(now.getDate() - i);
      const label = d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
      counts[label] = 0;
    }

    logs.forEach((log: any) => {
      try {
        const dateStr = new Date(log.timestamp).toLocaleDateString(undefined, { month: "short", day: "numeric" });
        if (counts[dateStr] !== undefined) {
          counts[dateStr] += 1;
        } else {
          counts[dateStr] = 1;
        }
      } catch (e) {}
    });

    return Object.keys(counts).map(key => ({
      name: key,
      Downloads: counts[key]
    }));
  };

  // 2. Process Device Split
  const getDeviceData = () => {
    let mobileCount = 0;
    let desktopCount = 0;
    let tabletCount = 0;

    logs.forEach((log: any) => {
      const dev = String(log.device || "").toLowerCase();
      if (dev.includes("mobile")) mobileCount++;
      else if (dev.includes("tablet")) tabletCount++;
      else desktopCount++;
    });

    // If zero down, supply high design placeholder
    if (logs.length === 0) {
      return [
        { name: "No telemetry yet", value: 1, color: "#cbd5e1" }
      ];
    }

    return [
      { name: "Desktop", value: desktopCount, color: "#3b82f6" },
      { name: "Mobile", value: mobileCount, color: "#10b981" },
      { name: "Tablet", value: tabletCount, color: "#8b5cf6" }
    ].filter(item => item.value > 0);
  };

  // 3. Process Browser Share
  const getBrowserData = () => {
    const counts: { [key: string]: number } = {};
    logs.forEach((log: any) => {
      const br = log.browser || "Other";
      counts[br] = (counts[br] || 0) + 1;
    });

    const data = Object.keys(counts).map(key => ({
      name: key,
      Count: counts[key]
    }));

    return data.length > 0 ? data : [{ name: "No Data", Count: 0 }];
  };

  const timelineData = getTimelineData();
  const deviceData = getDeviceData();
  const browserData = getBrowserData();

  const PIE_COLORS = ["#3b82f6", "#10b981", "#8b5cf6", "#f59e0b", "#ec4899"];

  return (
    <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xl space-y-6 animate-fade-in text-left">
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <h3 className="font-display font-black text-slate-800 text-base tracking-tight flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-blue-600" />
            File Performance & Telemetry
          </h3>
          <p className="text-[11px] text-slate-500 font-mono mt-0.5 max-w-md truncate" title={fileData.fileName}>
            File: {fileData.fileName}
          </p>
        </div>
        <button
          onClick={onClose}
          className="p-1 px-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-[10px] font-bold text-slate-500 flex items-center justify-center gap-1 transition cursor-pointer"
        >
          <X className="w-3 h-3" />
          Close Dashboard
        </button>
      </div>

      {/* Telemetry Core Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-slate-50/50 border border-slate-100 p-4 rounded-2xl">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            <Users className="w-3.5 h-3.5 text-blue-500" />
            Downloads
          </div>
          <p className="text-2xl font-black text-slate-800 tracking-tight mt-1">{totalDownloads}</p>
        </div>

        <div className="bg-slate-50/50 border border-slate-100 p-4 rounded-2xl">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            <Smartphone className="w-3.5 h-3.5 text-emerald-500" />
            Mobile Rate
          </div>
          <p className="text-2xl font-black text-slate-800 tracking-tight mt-1">
            {totalDownloads > 0 
              ? `${Math.round((logs.filter((l: any) => String(l.device).toLowerCase().includes("mobile")).length / totalDownloads) * 100)}%`
              : "0%"
            }
          </p>
        </div>

        <div className="bg-slate-50/50 border border-slate-100 p-4 rounded-2xl">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            <Clock className="w-3.5 h-3.5 text-indigo-500" />
            Status Mode
          </div>
          <p className="text-xs font-bold text-slate-700 tracking-tight mt-2.5">
            {fileData.expiration && fileData.expiration !== "never" && Date.now() > new Date(fileData.expiration).getTime() ? (
              <span className="text-rose-600 font-semibold bg-rose-50 px-2.5 py-1 rounded-lg">Expired</span>
            ) : (
              <span className="text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded-lg">Live Share</span>
            )}
          </p>
        </div>

        <div className="bg-slate-50/50 border border-slate-100 p-4 rounded-2xl">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            <Info className="w-3.5 h-3.5 text-amber-500" />
            Lock Mode
          </div>
          <p className="text-xs font-bold text-slate-700 tracking-tight mt-2.5">
            {fileData.passwordHash ? (
              <span className="text-blue-700 font-semibold bg-blue-50 px-2.5 py-1 rounded-lg">Passworded</span>
            ) : (
              <span className="text-slate-500 font-semibold bg-slate-100 px-2.5 py-1 rounded-lg">Public</span>
            )}
          </p>
        </div>
      </div>

      {/* Line Chart & Device Splits Layout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Timeline Line Chart */}
        <div className="md:col-span-2 border border-slate-100 p-4 rounded-2xl bg-slate-50/30">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-3.5">
            <TrendingUp className="w-3.5 h-3.5 text-blue-500" />
            Recent Access Timeline Trends
          </span>
          <div className="w-full h-48 text-[11px] font-mono">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timelineData}>
                <XAxis dataKey="name" stroke="#94a3b8" tickLine={false} />
                <YAxis stroke="#94a3b8" tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ fontSize: "11px", borderRadius: "12px", border: "1px solid #e2e8f0" }} />
                <Line type="monotone" dataKey="Downloads" stroke="#2563eb" strokeWidth={3} activeDot={{ r: 6 }} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Device breakdown Pie chart */}
        <div className="border border-slate-100 p-4 rounded-2xl bg-slate-50/30 flex flex-col justify-between">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-2">
            <Smartphone className="w-3.5 h-3.5 text-emerald-500" />
            Device Breakdowns
          </span>
          <div className="h-32 relative text-[11px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={deviceData}
                  cx="50%"
                  cy="50%"
                  innerRadius={30}
                  outerRadius={45}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {deviceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color || PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ fontSize: "11.11px" }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          {/* Label Details */}
          <div className="flex justify-center gap-3.5 text-[10px] font-semibold text-slate-600 mt-2 font-mono flex-wrap">
            {deviceData.map((d: any, idx) => (
              <div key={idx} className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: d.color }} />
                <span>{d.name}: {d.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Row 3: Browsers Bar Chart & Historical logs */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        
        {/* Browser bars */}
        <div className="md:col-span-2 border border-slate-100 p-4 rounded-2xl bg-slate-50/30">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-3.5">
            <Compass className="w-3.5 h-3.5 text-indigo-500" />
            Browser Distribution
          </span>
          <div className="h-44 font-mono text-[11px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={browserData}>
                <XAxis dataKey="name" stroke="#94a3b8" tickLine={false} />
                <YAxis stroke="#94a3b8" tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ fontSize: "11px", borderRadius: "12px" }} />
                <Bar dataKey="Count" fill="#4f46e5" radius={[4, 4, 0, 0]} barSize={24} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Real-time raw log stream listing */}
        <div className="md:col-span-3 border border-slate-100 p-4 rounded-2xl bg-slate-50/30 flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-3">
              Access History Records Log ({logs.length})
            </span>
            <div className="max-h-40 overflow-y-auto divide-y divide-slate-100 pr-1">
              {logs.length === 0 ? (
                <div className="h-28 flex flex-col items-center justify-center text-slate-300 font-sans text-xs">
                  <span>No download telemetry events yet.</span>
                  <span className="text-[10px] opacity-70 mt-0.5">Telemetry streams automatically when anyone pulls the file link.</span>
                </div>
              ) : (
                logs.slice().reverse().map((log: any, idx: number) => (
                  <div key={idx} className="flex items-center justify-between py-2 text-[11px] font-mono">
                    <span className="text-slate-500">
                      {new Date(log.timestamp).toLocaleString(undefined, {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                        second: "2-digit"
                      })}
                    </span>
                    <div className="flex gap-2 font-semibold">
                      <span className="bg-blue-50 text-blue-600 px-2 py-0.5 rounded-lg border border-blue-100">{log.device}</span>
                      <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-lg">{log.browser}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
