import React, { useState, useEffect } from "react";
import { 
  Download, 
  Lock, 
  File, 
  FileText, 
  Video, 
  Image as ImageIcon, 
  Archive, 
  AlertCircle, 
  Clock, 
  CheckCircle,
  HelpCircle,
  ArrowRight,
  ShieldAlert,
  Loader2,
  ChevronLeft,
  Calendar,
  HardDrive
} from "lucide-react";
import { doc, getDoc, updateDoc, arrayUnion } from "firebase/firestore";
import { db } from "../lib/firebase";
import { motion, AnimatePresence } from "motion/react";

interface DownloadPageProps {
  fileId: string;
}

interface SharedFile {
  id: string;
  fileName: string;
  mimeType: string;
  size: number;
  uploadedAt: string;
  storagePath: string;
  downloadUrl: string;
  passwordHash?: string;
  expiration?: string;
  downloadCount: number;
  analytics?: any[];
}

export default function DownloadPage({ fileId }: DownloadPageProps) {
  const [fileData, setFileData] = useState<SharedFile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Password protection state
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  // Download progress states
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadSpeed, setDownloadSpeed] = useState("");
  const [downloadBytesLoaded, setDownloadBytesLoaded] = useState(0);
  const [isDownloadFinished, setIsDownloadFinished] = useState(false);

  // Load file configuration
  useEffect(() => {
    async function loadFileMetadata() {
      try {
        setLoading(true);
        const ref = doc(db, "shared_files", fileId);
        const snap = await getDoc(ref);
        
        if (!snap.exists()) {
          setError("This secure download link does not exist or has been permanently deleted.");
          setLoading(false);
          return;
        }

        const data = snap.data() as SharedFile;

        // Check expiration
        if (data.expiration && data.expiration !== "never") {
          const expTime = new Date(data.expiration).getTime();
          if (Date.now() > expTime) {
            setError("This download link has expired according to its security policy.");
            setLoading(false);
            return;
          }
        }

        setFileData(data);
        if (!data.passwordHash) {
          setIsAuthenticated(true);
        }
      } catch (err: any) {
        console.error("Error reading storage coordinate:", err);
        setError("Failed to verify secure file metadata. Check database logs.");
      } finally {
        setLoading(false);
      }
    }
    loadFileMetadata();
  }, [fileId]);

  // Helpers for formatting
  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const getFileIcon = (mime: string) => {
    const parentMime = mime.toLowerCase();
    if (parentMime.includes("image")) return <ImageIcon className="w-12 h-12 text-blue-500" />;
    if (parentMime.includes("video")) return <Video className="w-12 h-12 text-indigo-500" />;
    if (parentMime.includes("audio")) return <Video className="w-12 h-12 text-violet-500" />;
    if (parentMime.includes("pdf") || parentMime.includes("epub")) return <FileText className="w-12 h-12 text-rose-500" />;
    if (parentMime.includes("zip") || parentMime.includes("tar") || parentMime.includes("rar") || parentMime.includes("gz")) {
      return <Archive className="w-12 h-12 text-amber-500" />;
    }
    return <File className="w-12 h-12 text-slate-500" />;
  };

  // SHA-256 native client-side hashing
  const sha256 = async (str: string): Promise<string> => {
    const msgBuffer = new TextEncoder().encode(str);
    const hashBuffer = await crypto.subtle.digest("SHA-256", msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fileData || !password) return;

    try {
      const hashed = await sha256(password);
      if (hashed === fileData.passwordHash) {
        setIsAuthenticated(true);
        setPasswordError("");
      } else {
        setPasswordError("Incorrect security password. Please try again.");
      }
    } catch (err) {
      setPasswordError("Verification failed inside system sandbox.");
    }
  };

  // Device context detection for rich telemetry analytics
  const getDeviceType = () => {
    const ua = navigator.userAgent;
    if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(ua)) return "Tablet";
    if (/Mobile|iP(hone|od)|Android|BlackBerry|IEMobile|Kindle|Silk-Accelerated/.test(ua)) return "Mobile";
    return "Desktop";
  };

  const getBrowserName = () => {
    const ua = navigator.userAgent;
    if (ua.includes("Firefox")) return "Firefox";
    if (ua.includes("Edge") || ua.includes("Edg")) return "Edge";
    if (ua.includes("Chrome")) return "Chrome";
    if (ua.includes("Safari") && !ua.includes("Chrome")) return "Safari";
    return "Other";
  };

  const handleTriggerDownload = async () => {
    if (!fileData || isDownloading) return;

    try {
      setIsDownloading(true);
      setDownloadProgress(0);
      setDownloadBytesLoaded(0);

      const xhr = new XMLHttpRequest();
      const startTime = Date.now();

      xhr.open("GET", fileData.downloadUrl, true);
      xhr.responseType = "blob";

      xhr.onprogress = (event) => {
        if (event.lengthComputable) {
          const loaded = event.loaded;
          const total = event.total;
          const percentage = Math.round((loaded / total) * 100);
          
          setDownloadProgress(percentage);
          setDownloadBytesLoaded(loaded);

          // Calculate streaming rate speed
          const elapsedSecs = (Date.now() - startTime) / 1000;
          if (elapsedSecs > 0) {
            const speedBytesPerSec = loaded / elapsedSecs;
            if (speedBytesPerSec > 1024 * 1024) {
              setDownloadSpeed(`${(speedBytesPerSec / (1024 * 1024)).toFixed(1)} MB/s`);
            } else {
              setDownloadSpeed(`${(speedBytesPerSec / 1024).toFixed(0)} KB/s`);
            }
          }
        }
      };

      xhr.onload = async () => {
        if (xhr.status === 200) {
          const blob = xhr.response;
          const url = window.URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.href = url;
          link.setAttribute("download", fileData.fileName);
          document.body.appendChild(link);
          link.click();
          link.remove();
          window.URL.revokeObjectURL(url);

          setIsDownloadFinished(true);

          // Atomic stats increment
          try {
            const fileRef = doc(db, "shared_files", fileData.id);
            const downloadLog = {
              timestamp: new Date().toISOString(),
              browser: getBrowserName(),
              device: getDeviceType()
            };
            await updateDoc(fileRef, {
              downloadCount: fileData.downloadCount + 1,
              analytics: arrayUnion(downloadLog)
            });
            
            setFileData(prev => prev ? {
              ...prev,
              downloadCount: prev.downloadCount + 1
            } : null);
          } catch (e) {
            console.warn("Failed recording telemetry transaction:", e);
          }
        } else {
          alert("Network download request rejected by remote coordinate. Try direct fetch.");
        }
        setIsDownloading(false);
      };

      xhr.onerror = () => {
        setIsDownloading(false);
        alert("Failed to reach download coordinate. Check connectivity.");
      };

      xhr.send();

    } catch (e) {
      setIsDownloading(false);
      console.error(e);
      // Fallback direct link download
      window.open(fileData.downloadUrl, "_blank");
    }
  };

  if (loading) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center space-y-4">
        <Loader2 className="w-10 h-10 animate-spin text-blue-600" />
        <p className="text-sm font-semibold text-slate-500 font-display">Decrypting cloud location guidelines...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-md mx-auto bg-white border border-slate-100 rounded-3xl p-8 shadow-xl text-center space-y-6 mt-12 animate-fade-in">
        <div className="p-4 bg-rose-50 text-rose-500 rounded-full border border-rose-100 inline-block">
          <ShieldAlert className="w-10 h-10 mx-auto" />
        </div>
        <div>
          <h3 className="font-display font-black text-slate-800 text-xl">Cloud Coordinate Handshake Failed</h3>
          <p className="text-slate-400 text-xs mt-2 leading-relaxed">{error}</p>
        </div>
        <button
          onClick={() => { window.location.href = "/"; }}
          className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3.5 rounded-2xl flex items-center justify-center gap-2 transition text-xs shadow-md cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          Navigate to Upload Dashboard
        </button>
      </div>
    );
  }

  if (!fileData) return null;

  return (
    <div className="max-w-2xl mx-auto px-4 mt-8">
      <AnimatePresence mode="wait">
        {!isAuthenticated ? (
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="bg-white border border-slate-100 rounded-3xl p-8 shadow-xl text-center space-y-6"
          >
            <div className="p-4 bg-blue-50 text-blue-600 rounded-full border border-blue-100 inline-block">
              <Lock className="w-8 h-8" />
            </div>
            <div>
              <h2 className="font-display font-black text-slate-800 text-xl tracking-tight">Security Handshake Required</h2>
              <p className="text-slate-400 text-xs mt-1">This secure link is private and password-protected by the host.</p>
            </div>

            <form onSubmit={handlePasswordSubmit} className="space-y-4 max-w-sm mx-auto">
              <div className="relative">
                <input
                  type="password"
                  required
                  placeholder="Enter access password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full text-center font-semibold text-slate-800 bg-slate-50 border border-slate-200/80 focus:border-blue-500 focus:bg-white rounded-2xl py-3 px-4 focus:outline-none transition text-sm text-[16px]"
                />
              </div>

              {passwordError && (
                <div className="flex items-center gap-1.5 text-xs text-rose-500 justify-center">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{passwordError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-3.5 rounded-2xl flex items-center justify-center gap-2 transition text-xs shadow-md cursor-pointer"
              >
                Decrypt & Enter Download Vault
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white border border-slate-100 rounded-3xl p-8 shadow-xl md:p-10 space-y-8"
          >
            <div className="text-center space-y-3 pb-2 border-b border-slate-100">
              <div className="inline-block p-4 bg-slate-50 border border-slate-100 rounded-2xl shadow-3xs mb-1">
                {getFileIcon(fileData.mimeType)}
              </div>
              <h2 className="font-display font-black text-slate-800 text-xl tracking-tight break-all px-2" title={fileData.fileName}>
                {fileData.fileName}
              </h2>
              <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-500">
                <div className="flex items-center gap-1">
                  <HardDrive className="w-3.5 h-3.5 text-slate-400" />
                  <span className="font-semibold font-mono">{formatSize(fileData.size)}</span>
                </div>
                <div className="w-1.5 h-1.5 rounded-full bg-slate-200" />
                <div className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{new Date(fileData.uploadedAt).toLocaleDateString(undefined, { dateStyle: "medium" })}</span>
                </div>
              </div>
            </div>

            {/* Check Expiration Policy Warning Banner */}
            {fileData.expiration && fileData.expiration !== "never" && (
              <div className="bg-amber-50/70 border border-amber-200/50 p-3.5 rounded-2xl flex items-start gap-2.5 text-xs text-amber-700">
                <Clock className="w-4 h-4 mt-0.5 text-amber-600 flex-shrink-0" />
                <div>
                  <p className="font-bold">Temporary Secure Lockout Policy</p>
                  <p className="opacity-90 leading-relaxed mt-0.5">
                    This shared file link is ephemeral and will expire on <strong className="font-bold">{new Date(fileData.expiration).toLocaleString()}</strong>.
                  </p>
                </div>
              </div>
            )}

            {/* Downloader Trigger Section */}
            <div className="space-y-4">
              {isDownloading ? (
                <div className="bg-slate-50 border border-slate-200/60 p-5 rounded-2xl space-y-3">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-slate-700">Downloading File Buffer Chunks...</span>
                    <span className="font-mono text-slate-500 font-bold">{downloadProgress}%</span>
                  </div>
                  
                  {/* Outer Bar */}
                  <div className="w-full h-2.5 bg-slate-200/60 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-blue-600 transition-all duration-150 ease-out shadow-[0_0_8px_rgba(37,99,235,0.4)]"
                      style={{ width: `${downloadProgress}%` }}
                    />
                  </div>

                  <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                    <span>{formatSize(downloadBytesLoaded)} / {formatSize(fileData.size)}</span>
                    <span className="font-bold text-slate-500">{downloadSpeed}</span>
                  </div>
                </div>
              ) : isDownloadFinished ? (
                <div className="bg-emerald-50 border border-emerald-100 p-5 rounded-2xl text-center space-y-2 animate-fade-in">
                  <div className="inline-flex items-center gap-2 text-emerald-700 text-sm font-bold">
                    <CheckCircle className="w-5 h-5 text-emerald-500" />
                    <span>Download Completed Successfully!</span>
                  </div>
                  <p className="text-[11px] text-emerald-600/90 leading-relaxed">
                    The file content stream has been synthesized on your device storage. Check your browser's download folder.
                  </p>
                </div>
              ) : (
                <button
                  onClick={handleTriggerDownload}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white font-display font-bold py-4 rounded-2xl flex items-center justify-center gap-2.5 text-sm shadow-md transition transform active:scale-98 cursor-pointer"
                >
                  <Download className="w-4 h-4 animate-bounce" />
                  Pull Secure File Direct From Cloud
                </button>
              )}
            </div>

            {/* Public Security Stats */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                Trusted cloud storage checkout
              </span>
              <span>Downloads logged: <strong className="font-bold text-slate-600">{fileData.downloadCount}</strong></span>
            </div>

            {/* Create new Link Anchor */}
            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => { window.location.href = "/"; }}
                className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 font-semibold cursor-pointer"
              >
                Need to share files? Go to Cloud Uploader Dashboard &rarr;
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
