export interface SharedFile {
  name: string;
  size: number;
  type: string;
  relativePath: string;
  fileObject: File;
}

export interface FileMetadata {
  name: string;
  size: number;
  type: string;
  isFolder: boolean;
  fileCount: number;
  filesList?: { name: string; size: number; relativePath: string }[];
}

export interface TransferStats {
  speedBytesPerSec: number;
  percent: number;
  bytesSentOrReceived: number;
  totalBytes: number;
  elapsedSeconds: number;
  estimatedRemainingSeconds: number;
  currentFileName: string;
  currentFileIndex: number;
}
