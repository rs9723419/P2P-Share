import React, { useState, useEffect } from "react";
import { Send, Download, ShieldCheck, HelpCircle, Moon, Sun, CloudLightning } from "lucide-react";
import Header from "./components/Header";
import SendSection from "./components/SendSection";
import ReceiveSection from "./components/ReceiveSection";
import TechFeatures from "./components/TechFeatures";
import DownloadPage from "./components/DownloadPage";

export default function App() {
  const [activeTab, setActiveTab] = useState<"send" | "receive">("send");
  const [downloadFileId, setDownloadFileId] = useState<string | null>(null);
  const [theme, setTheme] = useState<"slate" | "cosmic">(() => {
    try {
      const saved = localStorage.getItem("app-theme");
      if (saved === "slate" || saved === "cosmic") {
        return saved;
      }
    } catch (e) {}
    return "slate";
  });

  const toggleTheme = () => {
    const nextTheme = theme === "slate" ? "cosmic" : "slate";
    setTheme(nextTheme);
    try {
      localStorage.setItem("app-theme", nextTheme);
    } catch (e) {}
  };

  // Inspect URL parameters and paths on boot to coordinate routing
  useEffect(() => {
    const path = window.location.pathname;
    const downloadMatch = path.match(/^\/(?:download|d)\/([a-zA-Z0-9_\-]+)/);
    
    if (downloadMatch && downloadMatch[1]) {
      setDownloadFileId(downloadMatch[1]);
    } else {
      const params = new URLSearchParams(window.location.search);
      const pin = params.get("pin");
      if (pin && /^\d{6}$/.test(pin)) {
        setActiveTab("receive");
      }
    }
  }, []);

  if (downloadFileId) {
    return (
      <div className={`theme-${theme} min-h-screen bg-slate-50/50 pb-16 font-sans transition-colors duration-300`}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          
          {/* Theme Switcher Header */}
          <div className="flex justify-between items-center pt-6 pb-4 mb-4">
            <button
              onClick={() => { window.location.href = "/"; }}
              className="flex items-center gap-1.5 font-display font-black text-slate-800 text-lg hover:opacity-85 select-none"
            >
              <CloudLightning className="w-5 h-5 text-blue-600 animate-pulse" />
              <span>P2P Cloud Share</span>
            </button>
            
            <button
              id="theme-toggle-btn"
              onClick={toggleTheme}
              className={`flex items-center gap-2 p-2 px-3.5 rounded-xl border border-slate-200/40 shadow-xs text-xs font-semibold cursor-pointer select-none transition-all duration-200 ${
                theme === "slate" 
                  ? "bg-slate-100 text-slate-700 hover:bg-slate-200/80" 
                  : "bg-slate-900 border-slate-800 text-slate-200 hover:bg-slate-800"
              }`}
            >
              {theme === "slate" ? (
                <>
                  <Moon className="w-3.5 h-3.5 text-blue-600 fill-blue-600/10" />
                  <span>Dark Mode</span>
                </>
              ) : (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />
                  <span>Light Mode</span>
                </>
              )}
            </button>
          </div>

          <main className="pt-4">
            <DownloadPage fileId={downloadFileId} />
          </main>

          <footer className="text-center mt-12 text-[11px] text-slate-400 font-sans">
            Secure Cloud File Share • Encrypted in transit • Advanced access controls & telemetry
          </footer>
        </div>
      </div>
    );
  }

  return (
    <div className={`theme-${theme} min-h-screen bg-slate-50/50 pb-16 font-sans transition-colors duration-300`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Simple Premium Dark/Light Mode Toggle Button */}
        <div className="flex justify-end pt-4 -mb-2 animate">
          <button
            id="theme-toggle-btn"
            onClick={toggleTheme}
            className={`flex items-center gap-2 p-2 px-3.5 rounded-xl border border-slate-200/40 shadow-xs text-xs font-semibold cursor-pointer select-none transition-all duration-200 ${
              theme === "slate" 
                ? "bg-slate-100 text-slate-700 hover:bg-slate-200/80" 
                : "bg-slate-900 border-slate-800 text-slate-200 hover:bg-slate-800"
            }`}
          >
            {theme === "slate" ? (
              <>
                <Moon className="w-3.5 h-3.5 text-blue-600 fill-blue-600/10" />
                <span>Dark Mode</span>
              </>
            ) : (
              <>
                <Sun className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />
                <span>Light Mode</span>
              </>
            )}
          </button>
        </div>
        
        {/* Top Header trust badge and branding */}
        <Header />

        {/* Dynamic Tab Switchers */}
        <div className="flex justify-center mb-8">
          <div className="bg-slate-100 p-1.5 rounded-2xl inline-flex gap-1 border border-slate-200/50 shadow-inner">
            <button
              id="tab-send-btn"
              onClick={() => setActiveTab("send")}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-display font-bold text-sm tracking-tight transition-all duration-200 cursor-pointer ${
                activeTab === "send"
                  ? "bg-white text-blue-600 shadow-md"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Send className="w-4 h-4" />
              Send Files / Folder
            </button>
            <button
              id="tab-receive-btn"
              onClick={() => setActiveTab("receive")}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-display font-bold text-sm tracking-tight transition-all duration-200 cursor-pointer ${
                activeTab === "receive"
                  ? "bg-white text-emerald-600 shadow-md"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Download className="w-4 h-4" />
              Receive WebRTC
            </button>
          </div>
        </div>

        {/* Dynamic Panel Selection */}
        <main className="transition duration-150 ease-out">
          {activeTab === "send" ? <SendSection /> : <ReceiveSection />}
        </main>

        {/* Technical architecture and security explanation panel */}
        <TechFeatures />

        {/* Simple inline FAQ / Trust builder */}
        <div className="mt-8 bg-slate-100/50 rounded-2xl border border-slate-200/30 p-5 text-xs text-slate-500 font-sans space-y-3.5 max-w-2xl mx-auto">
          <h4 className="font-bold text-slate-700 flex items-center gap-1">
            <HelpCircle className="w-3.5 h-3.5 text-blue-500" />
            Frequently Asked Questions (Trust & Privacy)
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="font-semibold text-slate-600">Where are my files uploaded?</p>
              <p className="mt-1 text-slate-500 leading-relaxed">
                They are securely stored inside an encrypted Google Cloud Storage / Firebase Storage bucket. Every file uploaded is protected by Zero-Trust Firestore rules and can optionally be password-shielded.
              </p>
            </div>
            <div>
              <p className="font-semibold text-slate-600">How do link expiration & password protection work?</p>
              <p className="mt-1 text-slate-500 leading-relaxed">
                You can select custom expiration limits (e.g., 1 hour, 1 day, or 7 days). Once expired, database handles lockout and storage deletes access. Passwords are cryptographically verified before download.
              </p>
            </div>
          </div>
        </div>

        {/* Footer credits */}
        <footer className="text-center mt-12 text-[11px] text-slate-400 font-sans">
          Secure Cloud Share • End-to-end secure tunnels under HTTPS • Built-in performance analytics & QR generator
        </footer>

      </div>
    </div>
  );
}
